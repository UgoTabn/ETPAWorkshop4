class SalleBase extends Phaser.Scene {
  constructor(){
    super("SalleBase")
  }

//counter = 0;
	
preload(){
	this.load.image('fondBase', 'assets/fondSalleBase.png');
	this.load.image('logoBase', 'assets/logoSalleBase.png');
  }

create(){
	this.add.image(400, 300, 'fondBase');
	this.add.image(512, 512, 'logoBase').setOrigin(0.5,0.5);
	this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
	var text = this.add.text(512, 384, 'Tap space to start', { font: '16px Courier', fill: '#00ff00' }).setOrigin(0.5,0.5);
}

update(){
 if (this.space.isDown) {
		this.scene.start("Salle1");
  }
}


}
