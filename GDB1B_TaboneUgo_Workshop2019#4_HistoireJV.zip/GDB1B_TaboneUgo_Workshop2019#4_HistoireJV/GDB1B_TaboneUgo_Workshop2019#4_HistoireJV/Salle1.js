class Salle1 extends Phaser.Scene {
  constructor(){
    super("Salle1")
  }

preload(){
	this.load.image('fondSalle1', 'assets/fondSalle1.png');
	    this.load.image("ball", "assets/ball2.png");
    this.load.image("pong", "assets/pong.png");
  }

create(){
	this.add.image(400, 300, 'fondBase');

}

update(){

}




}