class Salle3 extends Phaser.Scene {
  constructor(){
    super("Salle3")
  }

preload(){

  }

create(){

}

update(){

 // if (--------) {
//		this.scene.start("Salle4");
  //}
}
}