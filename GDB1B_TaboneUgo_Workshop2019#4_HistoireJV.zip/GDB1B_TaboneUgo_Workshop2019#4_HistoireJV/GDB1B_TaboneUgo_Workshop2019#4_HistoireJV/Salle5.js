class Salle5 extends Phaser.Scene {
  constructor(){
    super("Salle5")
  }

preload(){

  }

create(){

}

update(){

 // if (--------) {
//		this.scene.start("SalleFin");
 // }
}
}