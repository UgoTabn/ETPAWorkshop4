class Salle2 extends Phaser.Scene {
  constructor(){
    super("Salle2")
  }

preload(){

  }

create(){

}

update(){

 // if (--------) {
//		this.scene.start("Salle3");
 // }
}
}