class Salle4 extends Phaser.Scene {
  constructor(){
    super("Salle4")
  }

preload(){

  }

create(){

}

update(){

//  if (--------) {
//		this.scene.start("Salle5");
//  }
}
}