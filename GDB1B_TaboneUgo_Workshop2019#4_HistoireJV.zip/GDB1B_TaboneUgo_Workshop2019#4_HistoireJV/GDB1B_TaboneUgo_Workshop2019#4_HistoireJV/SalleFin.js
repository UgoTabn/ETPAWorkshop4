class SalleFin extends Phaser.Scene {
  constructor(){
    super("SalleFin")
  }

preload(){

  }

create(){

}

update(){

}
}